# Roadmap

## v0.1.x

- Stabilize metadata reading
- Improve genre classification accuracy
- Add better debug reports

## v0.2

- Online genre lookup
- Evidence-based genre scoring

## v0.3

- DJ Model framework

## v0.4

- Purple Disco Machine Decision Model

## v0.5

- Playlist Generator
