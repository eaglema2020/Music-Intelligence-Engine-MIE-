# Music Intelligence Engine PRD V0.1

## Product

Music Intelligence Engine is a local AI-agent-friendly DJ library organization skill.

## Version

v0.1.0-alpha

## Goals

- Scan a user-selected local music folder.
- Generate a Music Library JSON and M3U playlist.
- Copy music files into normalized filename output.
- Copy music files into experimental genre folders.
- Preserve original music files as read-only source files.
- Provide clear terminal feedback after each step.

## Non-Goals

- No GUI.
- No DJ Model.
- No playlist ranking.
- No real online genre lookup.
- No Traktor control.
- No database.

## Safety Requirements

- Never modify original music files.
- Never delete original music files.
- Never move original music files.
- Never rename original music files.
- Never overwrite existing output.
- Only copy files into the selected folder's `Music Intelligence/` directory.

## Output Structure

```text
Music Intelligence/
├── 音乐库 Library/
├── 音乐集合 Collections/
├── 报告 Reports/
└── 日志 Logs/
```

## Genre Classification

Genre classification is experimental in v0.1.0-alpha. The system uses local evidence and writes reports for review.

Online genre lookup is not implemented in this version.

## Acceptance Criteria

- `python skills/music_intelligence_engine/skill.py` starts successfully.
- Scanning generates `music_library.json` and `music_library.m3u`.
- Filename normalization copies files only.
- Genre classification copies files only.
- Reports are generated.
- Repeated operations create timestamped output.
- Tests pass with `python -m pytest skills/music_intelligence_engine/tests`.
