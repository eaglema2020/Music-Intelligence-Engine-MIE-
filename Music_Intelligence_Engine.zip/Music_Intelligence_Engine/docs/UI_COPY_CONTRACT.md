# UI Copy Contract

This file is the product copy contract for Music Intelligence Engine.

All terminal menus and core status messages must remain consistent across users, accounts, computers, and AI tools. Do not change this file casually. If product copy changes, update this contract and the snapshot tests in the same release.

## Rules

- All menu copy must be generated from `skills/music_intelligence_engine/engine/ui_text.py`.
- `skill.py` must call `ui_text` instead of hardcoding menu text.
- Tests must compare the output of `ui_text.py` against this contract.
- The second-level tools menu must always show every operation and its description.
- Completed operations must return to the full second-level tools menu.
- Do not replace this UI with shorter summaries in product output.
- Do not replace operation descriptions with placeholder summaries when showing, testing, documenting, or reporting the menu. Always show the full locked copy.

## Reporting Rule

When an AI tool, maintainer, test report, or release note describes the second-level menu, it must quote or reference the full locked menu copy. It must not replace the operation descriptions with placeholders or shorthand summaries.

Correct:

```text
1、标准化文件名 / Normalize Filenames
   将音乐文件复制到新的目录，并统一命名格式：
   Copy music files to a new folder and normalize filename format:
   Artist - Title (Mix Version).ext
   不修改原始文件 / Original files are never modified

2、音乐风格分类 / Classify by Genre
   按音乐风格复制到分类文件夹：
   Copy files into genre folders:
   Funky House, Disco House, Nu Disco, Soulful House, House,
   Tech House, Techno, Melodic House Techno, Progressive House
   先读取音频标签与本地知识库，低置信度才进入 Unknown Need Review
   Uses audio tags and local knowledge base; low confidence goes to Unknown Need Review
   不修改原始文件 / Original files are never modified
```

## START_MENU

```text
Music Intelligence Engine
──────────────────────────────────────

请输入 / Please enter:
1、选择文件夹并扫描 / Select Folder and Scan
0、退出程序 / Exit
```

## PATH_PROMPT

```text
请拖入或粘贴要扫描的音乐文件夹路径，然后按回车：
Drag or paste the music folder path, then press Enter:

提示 / Tips:

* macOS / Windows 都可以直接把文件夹拖到这里
  You can drag a folder here on macOS / Windows
* 也可以复制文件夹路径后粘贴
  You can also copy and paste the folder path
* 路径两边有引号也没关系
  Quotes around the path are OK
```

## SCAN_RESULT_24

```text
✓ 扫描完成 / Scan Complete

共发现 / Tracks Found：24 首音乐

✓ Music Library 已生成

生成位置 / Output Location：
```

## TOOLS_MENU_24

```text
Music Intelligence Engine
──────────────────────────────────────

✓ 扫描完成 / Scan Complete

共发现 / Tracks Found：24 首音乐

请输入 / Please enter:

1、标准化文件名 / Normalize Filenames
   将音乐文件复制到新的目录，并统一命名格式：
   Copy music files to a new folder and normalize filename format:
   Artist - Title (Mix Version).ext
   不修改原始文件 / Original files are never modified

2、音乐风格分类 / Classify by Genre
   按音乐风格复制到分类文件夹：
   Copy files into genre folders:
   Funky House, Disco House, Nu Disco, Soulful House, House,
   Tech House, Techno, Melodic House Techno, Progressive House
   先读取音频标签与本地知识库，低置信度才进入 Unknown Need Review
   Uses audio tags and local knowledge base; low confidence goes to Unknown Need Review
   不修改原始文件 / Original files are never modified

0、退出程序 / Exit
```

## SELECTED_TOOL_1

```text

已选择 / Selected：标准化文件名 / Normalize Filenames

```

## SELECTED_TOOL_2

```text

已选择 / Selected：音乐风格分类 / Classify by Genre

```

## PROCESSING

```text
开始处理… / Processing…

```

## DONE

```text

✓ 处理完成 / Done

```

## OUTPUT_LOCATION

```text
输出位置 / Output Location：
```

## REPORT_LOCATION

```text

报告位置 / Report Location：
```
