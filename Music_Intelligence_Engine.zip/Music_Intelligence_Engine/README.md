# Music Intelligence Engine

A local AI-agent-friendly DJ library organization skill.

一个适合 AI Agent / Codex 使用的本地 DJ 曲库整理 Skill。

## Current Version

v0.1.0-alpha

## Current Features

- Scan a local music folder
- Generate `music_library.json` and `music_library.m3u`
- Normalize copied music filenames
- Experimental genre classification
- Generate metadata debug reports
- Copy-only output workflow
- Bilingual output folder structure

## Installation

```bash
pip install -r requirements.txt
```

Music Intelligence Engine v0.1.0-alpha uses only the Python standard library at runtime.

For development and release verification:

```bash
pip install -r requirements-dev.txt
```

## Run

```bash
python skills/music_intelligence_engine/skill.py
```

The Skill uses synchronous terminal input. Drag or paste the music folder path when prompted.

## Output Location

All output is generated inside the selected music folder:

```text
Music Intelligence/
├── 音乐库 Library/
│   ├── music_library.json
│   └── music_library.m3u
├── 音乐集合 Collections/
│   ├── 文件名整理 Renamed/
│   └── 曲风分类 By Genre/
├── 报告 Reports/
└── 日志 Logs/
```

Repeated tool runs create timestamped result folders and report files. Existing output is not overwritten.

## Safety

Music Intelligence Engine never modifies, deletes, moves, renames, or overwrites original music files.

The Skill only copies files into the selected folder's `Music Intelligence/` directory.

## Genre Classification

Genre Classification is experimental.

曲风分类仍是实验功能，请以报告为准。

The current alpha uses local evidence only: audio metadata when readable, folder path, filename, and local knowledge files. Online genre lookup is not implemented yet. If online lookup is requested, the terminal explicitly prints:

```text
在线曲风查询：未实现，本次未联网查询。
```

## Reports

Genre classification generates:

- `Music Intelligence/报告 Reports/metadata_debug_report.csv`
- `Music Intelligence/报告 Reports/genre_classification_report.csv`

If `metadata_genre` is read, it is written to `music_library.json`, `metadata_debug_report.csv`, and `genre_classification_report.csv`.

## Tests

Install development dependencies first:

```bash
pip install -r requirements-dev.txt
```

```bash
python -m pytest skills/music_intelligence_engine/tests
```

On systems where the command is named `python3`, run:

```bash
python3 -m pytest skills/music_intelligence_engine/tests
```

## UI Copy Contract

Terminal UI copy is locked by:

```text
docs/UI_COPY_CONTRACT.md
```

The test suite compares menus and core status messages against this contract exactly. Any change to menu wording, line breaks, bilingual labels, or operation descriptions must update the contract intentionally and pass the snapshot tests.

When reporting or documenting the second-level menu, do not replace descriptions with placeholder summaries. Always show the complete locked copy from the contract.

## Roadmap

- More accurate online genre recognition
- DJ Model
- Purple Disco Machine model
- Playlist Generator
- Mix Notes
