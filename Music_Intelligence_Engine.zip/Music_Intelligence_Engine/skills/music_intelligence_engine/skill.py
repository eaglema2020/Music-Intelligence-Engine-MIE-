"""Interactive Music Intelligence Engine Skill."""

from pathlib import Path

from engine.filename_normalizer import normalize_files_from_library
from engine.folder_picker import clean_dragged_path
from engine.genre_classifier import classify_genres_from_library
from engine.library_scanner import load_music_library, scan_music_folder
from engine.progress import render_progress
from engine.safety_guard import music_library_dir
from engine.status import input_status, print_status
from engine import ui_text


def print_start_menu() -> None:
    print_status(ui_text.START_MENU)


def print_path_prompt() -> None:
    print_status(ui_text.PATH_PROMPT)


def print_scan_progress(current: int, total: int) -> None:
    print_status("\r" + render_progress(current, total), end="")
    if current >= total:
        print_status()


def print_scan_result(selected_folder: str, track_count: int) -> None:
    library_dir = music_library_dir(selected_folder)
    print_status(ui_text.scan_result(track_count))
    print_status(str(library_dir / "music_library.json"))
    print_status(str(library_dir / "music_library.m3u"))


def print_tools_menu(track_count: int) -> None:
    print_status(ui_text.tools_menu(track_count))


def prompt_choice() -> str:
    try:
        return input_status("").strip()
    except EOFError:
        return "0"


def prompt_folder_path() -> str:
    try:
        return clean_dragged_path(input_status("").strip())
    except EOFError:
        return ""


def scan_selected_folder(selected_folder: str) -> dict:
    print_status(ui_text.SELECTED_FOLDER)
    print_status(selected_folder)
    print_status(ui_text.SCANNING_FILES)
    return scan_music_folder(
        selected_folder,
        show_progress=False,
        progress_callback=print_scan_progress,
    )


def run_tools_loop(selected_folder: str, track_count: int) -> int:
    print_tools_menu(track_count)
    while True:
        choice = prompt_choice()
        if choice == "0":
            return 0

        tracks = load_music_library(selected_folder)
        if choice == "1":
            print_status(ui_text.selected_tool_1())
            print_status(ui_text.PROCESSING)
            result = normalize_files_from_library(tracks, selected_folder)
            print_status(ui_text.DONE)
            print_status(ui_text.OUTPUT_LOCATION)
            print_status(result["output_dir"])
            print_status(ui_text.REPORT_LOCATION)
            print_status(result["report_path"])
            print_tools_menu(track_count)
            continue

        if choice == "2":
            print_status(ui_text.selected_tool_2())
            print_status(ui_text.PROCESSING)
            result = classify_genres_from_library(tracks, selected_folder)
            print_status(ui_text.DONE)
            print_status(ui_text.OUTPUT_LOCATION)
            print_status(result["output_dir"])
            print_status(ui_text.REPORT_LOCATION)
            print_status(result["report_path"])
            print_tools_menu(track_count)
            continue

        print_status(ui_text.INVALID_OPTION)
        print_tools_menu(track_count)


def main_loop() -> int:
    while True:
        print_start_menu()
        choice = prompt_choice()
        if choice == "0":
            return 0
        if choice != "1":
            print_status(ui_text.INVALID_OPTION)
            continue

        while True:
            print_path_prompt()
            selected_folder = prompt_folder_path()
            if not selected_folder:
                print_status(ui_text.INVALID_PATH)
                continue
            path = Path(selected_folder).expanduser()
            if not path.exists() or not path.is_dir():
                print_status(ui_text.INVALID_PATH)
                continue
            selected_folder = str(path.resolve())
            break

        try:
            result = scan_selected_folder(selected_folder)
        except FileNotFoundError:
            print_status(ui_text.INVALID_PATH)
            continue

        print_scan_result(selected_folder, result["total"])
        return run_tools_loop(selected_folder, result["total"])


def framework_ready() -> str:
    return "Music Intelligence Engine Ready"


def main() -> int:
    return main_loop()


if __name__ == "__main__":
    raise SystemExit(main())
