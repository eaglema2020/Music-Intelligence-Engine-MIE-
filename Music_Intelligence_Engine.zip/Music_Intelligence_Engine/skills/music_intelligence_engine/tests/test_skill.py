"""Tests for Music Intelligence Engine Skill."""

import json
import sys
import tempfile
import unittest
import csv
import io
from contextlib import redirect_stdout
from pathlib import Path


SKILL_DIR = Path(__file__).resolve().parents[1]
REPO_DIR = SKILL_DIR.parents[1]
sys.path.insert(0, str(SKILL_DIR))

from engine.audio_tags import read_audio_tags
from engine import ui_text
from engine.library_scanner import scan_music_folder
from engine.folder_picker import clean_dragged_path
from engine.genre_classifier import (
    classify_genres_from_library,
    collect_local_evidence,
    copy_files_by_final_decision,
    make_final_decision,
    make_local_decision,
    prepare_genre_dirs,
)
from engine.genre_decision_engine import decide_genre
from engine.knowledge_loader import load_knowledge_base
from engine.filename_normalizer import normalize_files_from_library
from engine.safety_guard import assert_safe_output_path, output_run_paths, safe_copy_file
from skill import (
    framework_ready,
    prompt_choice,
    prompt_folder_path,
    print_path_prompt,
    print_scan_result,
    print_start_menu,
    print_tools_menu,
)


class MusicIntelligenceEngineTest(unittest.TestCase):
    def test_skill_can_start(self):
        self.assertEqual(framework_ready(), "Music Intelligence Engine Ready")

    def test_prompt_choice_exits_cleanly_on_eof(self):
        original_input = __builtins__["input"] if isinstance(__builtins__, dict) else __builtins__.input

        def fake_input(prompt=""):
            raise EOFError

        if isinstance(__builtins__, dict):
            __builtins__["input"] = fake_input
        else:
            __builtins__.input = fake_input
        try:
            self.assertEqual(prompt_choice(), "0")
        finally:
            if isinstance(__builtins__, dict):
                __builtins__["input"] = original_input
            else:
                __builtins__.input = original_input

    def test_prompt_folder_path_returns_empty_on_eof(self):
        original_input = __builtins__["input"] if isinstance(__builtins__, dict) else __builtins__.input

        def fake_input(prompt=""):
            raise EOFError

        if isinstance(__builtins__, dict):
            __builtins__["input"] = fake_input
        else:
            __builtins__.input = fake_input
        try:
            self.assertEqual(prompt_folder_path(), "")
        finally:
            if isinstance(__builtins__, dict):
                __builtins__["input"] = original_input
            else:
                __builtins__.input = original_input

    def test_library_scanner_scans_test_directory(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "Artist - Title.mp3").write_bytes(b"fake")
            (root / "cover.jpg").write_bytes(b"image")
            result = scan_music_folder(str(root), show_progress=False)
            self.assertEqual(result["total"], 1)
            self.assertEqual(result["tracks"][0]["id"], "MIE000001")

    def test_library_scanner_reads_mp3_id3_genre_tag(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            mp3 = root / "Artist - Title.mp3"
            write_fake_id3_mp3(mp3, {"TCON": "Techno (Peak Time / Driving)", "TPE1": "Artist", "TIT2": "Title"})

            result = scan_music_folder(str(root), show_progress=False)
            track = result["tracks"][0]

            self.assertEqual(track["genre"], "Techno (Peak Time / Driving)")
            self.assertEqual(track["artist"], "Artist")
            self.assertEqual(track["title"], "Title")
            self.assertEqual(track["tag_read_status"], "READ")

    def test_read_audio_tags_extracts_id3_text_frames(self):
        with tempfile.TemporaryDirectory() as tmp:
            mp3 = Path(tmp) / "Tagged.mp3"
            write_fake_id3_mp3(mp3, {"TCON": "Funky House", "TPUB": "Glitterbox"})

            tags = read_audio_tags(mp3)

            self.assertEqual(tags["genre"], "Funky House")
            self.assertEqual(tags["label"], "Glitterbox")

    def test_generates_music_library_json(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "Artist - Title.wav").write_bytes(b"fake")
            result = scan_music_folder(str(root), show_progress=False)
            path = Path(result["json_path"])
            self.assertTrue(path.exists())
            data = json.loads(path.read_text(encoding="utf-8"))
            self.assertEqual(data[0]["status"], "SCANNED")

    def test_generates_music_library_m3u(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "Artist - Title.flac").write_bytes(b"fake")
            result = scan_music_folder(str(root), show_progress=False)
            path = Path(result["m3u_path"])
            self.assertTrue(path.exists())
            self.assertTrue(path.read_text(encoding="utf-8").startswith("#EXTM3U"))

    def test_scanner_supports_release_audio_extensions_and_safe_names(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "Music Folder With Spaces"
            root.mkdir()
            filenames = [
                "中文艺人 - 中文歌名.mp3",
                "English Artist - Track Name.wav",
                "Artist & Friend - Title (Extended Mix).aiff",
                "Artist - Title #1.aif",
                "Artist - Title [Special].flac",
                "Artist - Title.m4a",
            ]
            for filename in filenames:
                path = root / filename
                if path.suffix == ".mp3":
                    write_fake_id3_mp3(path, {"TCON": "Funky House", "TPE1": "中文艺人", "TIT2": "中文歌名"})
                else:
                    path.write_bytes(b"fake")

            result = scan_music_folder(str(root), show_progress=False)
            scanned_names = {track["filename"] for track in result["tracks"]}

            self.assertEqual(result["total"], 6)
            self.assertEqual(scanned_names, set(filenames))
            self.assertEqual({track["extension"] for track in result["tracks"]}, {".mp3", ".wav", ".aiff", ".aif", ".flac", ".m4a"})

    def test_empty_folder_returns_no_supported_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = scan_music_folder(tmp, show_progress=False)

            self.assertEqual(result["status"], "NO_SUPPORTED_FILES")
            self.assertEqual(result["total"], 0)
            self.assertTrue(Path(result["json_path"]).exists())
            self.assertTrue(Path(result["m3u_path"]).exists())
            self.assertEqual(json.loads(Path(result["json_path"]).read_text(encoding="utf-8")), [])

    def test_invalid_folder_raises_file_not_found(self):
        with tempfile.TemporaryDirectory() as tmp:
            missing = Path(tmp) / "missing"

            with self.assertRaises(FileNotFoundError):
                scan_music_folder(str(missing), show_progress=False)

    def test_no_genre_tag_is_scanned_without_metadata_genre(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "Artist - Title.mp3"
            source.write_bytes(b"fake")

            result = scan_music_folder(str(root), show_progress=False)
            track = result["tracks"][0]

            self.assertEqual(track["genre"], "")
            self.assertIn(track["tag_read_status"], {"NO_ID3_TAG", "NO_TEXT_TAGS"})

    def test_safety_guard_rejects_outside_music_intelligence(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            with self.assertRaises(ValueError):
                assert_safe_output_path(root / "outside.mp3", root)

    def test_safe_copy_file_does_not_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "source.mp3"
            source.write_bytes(b"fake")
            destination = root / "Music Intelligence" / "音乐集合 Collections" / "文件名整理 Renamed" / "source.mp3"
            first = safe_copy_file(source, destination, root)
            second = safe_copy_file(source, destination, root)
            self.assertEqual(first["status"], "COPIED")
            self.assertEqual(second["status"], "COPIED")
            self.assertNotEqual(first["copied_path"], second["copied_path"])

    def test_safe_copy_file_can_cancel_on_existing_destination(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "source.mp3"
            source.write_bytes(b"fake")
            destination = root / "Music Intelligence" / "音乐集合 Collections" / "文件名整理 Renamed" / "source.mp3"
            safe_copy_file(source, destination, root)
            cancelled = safe_copy_file(source, destination, root, conflict_strategy="cancel")

            self.assertEqual(cancelled["status"], "CANCELLED_EXISTS")

    def test_safe_copy_file_rejects_overwrite_strategy(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "source.mp3"
            destination = root / "Music Intelligence" / "音乐集合 Collections" / "文件名整理 Renamed" / "source.mp3"
            source.write_bytes(b"fake")

            with self.assertRaises(ValueError):
                safe_copy_file(source, destination, root, conflict_strategy="overwrite")

    def test_output_run_paths_add_timestamp_when_output_exists(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            existing = root / "Music Intelligence" / "音乐集合 Collections" / "文件名整理 Renamed"
            existing.mkdir(parents=True)

            paths = output_run_paths(root, "文件名整理 Renamed", "filename_normalization_report.csv")

            self.assertIn("文件名整理 Renamed_", paths["output_dir"].name)
            self.assertIn("filename_normalization_report_", paths["report_path"].name)

    def test_filename_normalizer_uses_timestamped_output_when_default_exists(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "Artist - Title.mp3"
            source.write_bytes(b"fake")
            (root / "Music Intelligence" / "音乐集合 Collections" / "文件名整理 Renamed").mkdir(parents=True)
            tracks = [{"file_path": str(source), "filename": source.name}]

            result = normalize_files_from_library(tracks, str(root))

            self.assertIn("文件名整理 Renamed_", Path(result["output_dir"]).name)
            self.assertIn("filename_normalization_report_", Path(result["report_path"]).name)

    def test_genre_classifier_uses_timestamped_output_when_default_exists(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source_dir = root / "Funky House"
            source_dir.mkdir()
            source = source_dir / "Artist - Title.mp3"
            source.write_bytes(b"fake")
            (root / "Music Intelligence" / "音乐集合 Collections" / "曲风分类 By Genre").mkdir(parents=True)
            tracks = [{
                "file_path": str(source),
                "filename": source.name,
                "parent_folder": str(source_dir),
                "artist": "",
                "title": "",
                "mix_version": "",
                "genre": "",
            }]

            result = classify_genres_from_library(tracks, str(root), prompt_fn=lambda prompt: "n")

            self.assertIn("曲风分类 By Genre_", Path(result["output_dir"]).name)
            self.assertIn("genre_classification_report_", Path(result["report_path"]).name)

    def test_no_dangerous_file_operations(self):
        skill_root = SKILL_DIR
        dangerous = [
            "os" + ".remove",
            "os" + ".rename",
            "shutil" + ".move",
            "Path" + ".unlink",
            "." + "unlink(",
            "shutil" + "." + "rm" + "tree",
            "." + "rename(",
        ]
        for path in skill_root.rglob("*.py"):
            text = path.read_text(encoding="utf-8")
            if path.name == "test_skill.py":
                continue
            for token in dangerous:
                self.assertNotIn(token, text, f"{token} found in {path}")

    def test_clean_dragged_path_handles_quotes_and_macos_escapes(self):
        value = clean_dragged_path("' /Users/example/Music\\ Folder/Test '")

        self.assertEqual(value, "/Users/example/Music Folder/Test")

    def test_start_menu_is_multiline(self):
        buffer = io.StringIO()
        with redirect_stdout(buffer):
            print_start_menu()

        rendered = buffer.getvalue()
        self.assertIn("请输入 / Please enter:", rendered)
        self.assertIn("1、选择文件夹并扫描 / Select Folder and Scan", rendered)
        self.assertIn("0、退出程序 / Exit", rendered)

    def test_path_prompt_asks_for_dragged_or_pasted_path(self):
        buffer = io.StringIO()
        with redirect_stdout(buffer):
            print_path_prompt()

        rendered = buffer.getvalue()
        self.assertIn("请拖入或粘贴要扫描的音乐文件夹路径，然后按回车：", rendered)
        self.assertIn("Drag or paste the music folder path, then press Enter:", rendered)
        self.assertIn("路径两边有引号也没关系", rendered)
        self.assertIn("Quotes around the path are OK", rendered)

    def test_scan_result_prints_library_paths(self):
        buffer = io.StringIO()
        with redirect_stdout(buffer):
            print_scan_result("/music/root", 24)

        rendered = buffer.getvalue()
        self.assertIn("✓ 扫描完成", rendered)
        self.assertIn("共发现 / Tracks Found：24 首音乐", rendered)
        self.assertIn("/music/root/Music Intelligence/音乐库 Library/music_library.json", rendered)
        self.assertIn("/music/root/Music Intelligence/音乐库 Library/music_library.m3u", rendered)

    def test_tools_menu_prints_required_choices(self):
        buffer = io.StringIO()
        with redirect_stdout(buffer):
            print_tools_menu(24)

        rendered = buffer.getvalue()
        self.assertIn("共发现 / Tracks Found：24 首音乐", rendered)
        self.assertIn("请输入 / Please enter:", rendered)
        self.assertIn("1、标准化文件名 / Normalize Filenames", rendered)
        self.assertIn("Artist - Title (Mix Version).ext", rendered)
        self.assertIn("2、音乐风格分类 / Classify by Genre", rendered)
        self.assertIn("Funky House, Disco House, Nu Disco", rendered)
        self.assertIn("Unknown Need Review", rendered)
        self.assertIn("0、退出程序 / Exit", rendered)

    def test_ui_copy_is_centralized_in_ui_text_module(self):
        skill_text = (SKILL_DIR / "skill.py").read_text(encoding="utf-8")

        self.assertIn("ui_text.START_MENU", skill_text)
        self.assertIn("ui_text.tools_menu", skill_text)
        self.assertIn("ui_text.PATH_PROMPT", skill_text)
        self.assertIn("Normalize Filenames", ui_text.tools_menu(24))
        self.assertIn("Classify by Genre", ui_text.tools_menu(24))

    def test_ui_copy_contract_start_menu_is_exact(self):
        self.assertEqual(ui_text.START_MENU, contract_block("START_MENU"))

    def test_ui_copy_contract_path_prompt_is_exact(self):
        self.assertEqual(ui_text.PATH_PROMPT, contract_block("PATH_PROMPT"))

    def test_ui_copy_contract_scan_result_is_exact(self):
        self.assertEqual(ui_text.scan_result(24), contract_block("SCAN_RESULT_24"))

    def test_ui_copy_contract_tools_menu_is_exact(self):
        self.assertEqual(ui_text.tools_menu(24), contract_block("TOOLS_MENU_24"))

    def test_ui_copy_contract_rejects_placeholder_menu_descriptions(self):
        menu = ui_text.tools_menu(24)

        self.assertNotIn("标准化文件名" + "说明文案", menu)
        self.assertNotIn("音乐风格分类" + "说明文案", menu)
        self.assertIn("将音乐文件复制到新的目录，并统一命名格式：", menu)
        self.assertIn("按音乐风格复制到分类文件夹：", menu)

    def test_print_tools_menu_matches_locked_contract(self):
        buffer = io.StringIO()
        with redirect_stdout(buffer):
            print_tools_menu(24)

        self.assertEqual(buffer.getvalue(), contract_block("TOOLS_MENU_24") + "\n")

    def test_ui_copy_contract_core_status_messages_are_exact(self):
        self.assertEqual(ui_text.selected_tool_1(), contract_block("SELECTED_TOOL_1"))
        self.assertEqual(ui_text.selected_tool_2(), contract_block("SELECTED_TOOL_2"))
        self.assertEqual(ui_text.PROCESSING, contract_block("PROCESSING"))
        self.assertEqual(ui_text.DONE, contract_block("DONE"))
        self.assertEqual(ui_text.OUTPUT_LOCATION, contract_block("OUTPUT_LOCATION"))
        self.assertEqual(ui_text.REPORT_LOCATION, contract_block("REPORT_LOCATION"))

    def test_genre_sorted_uses_normalized_filename(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "[muzhousebeat.com] Purple Disco Machine - Body Funk (Extended Mix) 320kbps Promo 2024.mp3"
            source.write_bytes(b"fake")
            tracks = [
                {
                    "file_path": str(source),
                    "filename": source.name,
                    "parent_folder": str(root / "Funky House"),
                    "artist": "",
                    "title": "",
                    "mix_version": "",
                    "genre": "",
                }
            ]

            result = classify_genres_from_library(tracks, str(root), prompt_fn=lambda prompt: "n")
            copied_path = Path(result["rows"][0]["copied_path"])

            self.assertEqual(copied_path.name, "Purple Disco Machine - Body Funk (Extended Mix).mp3")
            self.assertIn("01_Funky House", str(copied_path))

    def test_decide_genre_funky_house_from_path(self):
        decision = decide_genre({"parent_folder": "/music/Funky House", "filename": "Track.mp3"})

        self.assertEqual(decision["primary_genre"], "Funky House")
        self.assertEqual(decision["target_folder"], "01_Funky House")
        self.assertGreaterEqual(decision["confidence"], 85)

    def test_decide_genre_disco_house_from_path(self):
        decision = decide_genre({"parent_folder": "/music/Disco House", "filename": "Track.mp3"})

        self.assertEqual(decision["primary_genre"], "Disco House")
        self.assertEqual(decision["target_folder"], "02_Disco House")

    def test_decide_genre_tech_house_from_path(self):
        decision = decide_genre({"parent_folder": "/music/Tech House", "filename": "Track.mp3"})

        self.assertEqual(decision["primary_genre"], "Tech House")
        self.assertEqual(decision["target_folder"], "06_Tech House")

    def test_decide_genre_progressive_house_from_path(self):
        decision = decide_genre({"parent_folder": "/music/Progressive House", "filename": "Track.mp3"})

        self.assertEqual(decision["primary_genre"], "Progressive House")
        self.assertEqual(decision["target_folder"], "09_Progressive House")

    def test_decide_genre_generic_house_is_last_and_capped(self):
        decision = decide_genre({"parent_folder": "/music/House", "filename": "Track.mp3"})

        self.assertEqual(decision["primary_genre"], "House")
        self.assertLessEqual(decision["confidence"], 80)

    def test_decide_genre_unknown_when_no_local_genre_evidence(self):
        decision = decide_genre({"parent_folder": "/music/Misc", "filename": "Artist - Title.mp3"})

        self.assertEqual(decision["review_status"], "UNKNOWN_NEED_REVIEW")
        self.assertEqual(decision["target_folder"], "10_Unknown Need Review")

    def test_funky_house_is_not_classified_as_house(self):
        decision = decide_genre({"parent_folder": "/music/Funky House", "filename": "Track.mp3"})

        self.assertEqual(decision["primary_genre"], "Funky House")
        self.assertNotEqual(decision["primary_genre"], "House")

    def test_tech_house_is_not_classified_as_house(self):
        decision = decide_genre({"parent_folder": "/music/Tech House", "filename": "Track.mp3"})

        self.assertEqual(decision["primary_genre"], "Tech House")
        self.assertNotEqual(decision["primary_genre"], "House")

    def test_medium_confidence_copies_to_primary_genre_with_review_marker(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "Artist - Track.mp3"
            source.write_bytes(b"fake")
            tracks = [{
                "file_path": str(source),
                "filename": source.name,
                "parent_folder": str(root / "Inbox"),
                "artist": "",
                "title": "Disco House Track",
                "mix_version": "",
                "genre": "",
            }]

            result = classify_genres_from_library(tracks, str(root), prompt_fn=lambda prompt: "n")
            row = result["rows"][0]

            self.assertEqual(row["final_primary_genre"], "Disco House")
            self.assertEqual(row["review_status"], "REVIEW_RECOMMENDED")
            self.assertIn("02_Disco House", row["copied_path"])
            self.assertNotIn("10_Unknown Need Review", row["copied_path"])

    def test_artist_knowledge_classifies_but_requires_review(self):
        decision = decide_genre({
            "parent_folder": "/music/Inbox",
            "filename": "Purple Disco Machine - Body Funk.mp3",
            "artist": "Purple Disco Machine",
            "title": "Body Funk",
        })

        self.assertIn(decision["primary_genre"], ["Disco House", "Nu Disco"])
        self.assertLessEqual(decision["confidence"], 75)
        self.assertEqual(decision["review_status"], "REVIEW_RECOMMENDED")
        self.assertNotEqual(decision["target_folder"], "10_Unknown Need Review")

    def test_knowledge_loader_loads_core_files(self):
        knowledge = load_knowledge_base()

        self.assertIn("purple disco machine", knowledge["artists"])
        self.assertIn("glitterbox", knowledge["labels"])
        self.assertIn("claptone", knowledge["remixers"])
        self.assertIn("Funky House", knowledge["genre_keywords"])

    def test_purple_disco_machine_body_funk_uses_artist_knowledge(self):
        decision = decide_genre({"filename": "Purple Disco Machine - Body Funk.mp3"})

        self.assertIn(decision["primary_genre"], ["Disco House", "Nu Disco"])
        self.assertIn(decision["review_status"], ["REVIEW_RECOMMENDED", "CONFIDENT"])
        self.assertNotEqual(decision["target_folder"], "10_Unknown Need Review")

    def test_dr_packer_uses_artist_knowledge(self):
        decision = decide_genre({"filename": "Dr Packer - Track.mp3"})

        self.assertIn(decision["primary_genre"], ["Disco House", "Nu Disco"])
        self.assertNotEqual(decision["target_folder"], "10_Unknown Need Review")

    def test_carl_cox_uses_artist_knowledge(self):
        decision = decide_genre({"filename": "Carl Cox - Track.mp3"})

        self.assertEqual(decision["primary_genre"], "Techno")
        self.assertNotEqual(decision["target_folder"], "10_Unknown Need Review")

    def test_tale_of_us_uses_artist_knowledge(self):
        decision = decide_genre({"filename": "Tale Of Us - Track.mp3"})

        self.assertEqual(decision["primary_genre"], "Melodic House Techno")
        self.assertNotEqual(decision["target_folder"], "10_Unknown Need Review")

    def test_unknown_track_in_funky_house_folder_uses_folder_keyword(self):
        decision = decide_genre({"parent_folder": "/music/Funky House", "filename": "Unknown Track.wav"})

        self.assertEqual(decision["primary_genre"], "Funky House")

    def test_unknown_track_in_tech_house_folder_uses_folder_keyword(self):
        decision = decide_genre({"parent_folder": "/music/Tech House", "filename": "Unknown Track.wav"})

        self.assertEqual(decision["primary_genre"], "Tech House")

    def test_random_folder_unknown_track_enters_unknown_review(self):
        decision = decide_genre({"parent_folder": "/music/Random Folder", "filename": "Unknown Track.wav"})

        self.assertEqual(decision["review_status"], "UNKNOWN_NEED_REVIEW")
        self.assertEqual(decision["target_folder"], "10_Unknown Need Review")

    def test_download_site_watermark_does_not_trigger_house_keyword(self):
        decision = decide_genre({
            "parent_folder": "/music/Random Folder",
            "filename": "[muzhousebeat.com] Unknown Artist - Unknown Track.mp3",
        })

        self.assertEqual(decision["review_status"], "UNKNOWN_NEED_REVIEW")
        self.assertEqual(decision["target_folder"], "10_Unknown Need Review")

    def test_label_and_artist_same_direction_boosts_confidence(self):
        decision = decide_genre({
            "filename": "Purple Disco Machine - Body Funk.mp3",
            "artist": "Purple Disco Machine",
            "label": "Glitterbox",
        })

        self.assertEqual(decision["primary_genre"], "Disco House")
        self.assertGreaterEqual(decision["confidence"], 85)
        self.assertIn("Label knowledge", decision["evidence_sources"])

    def test_genre_report_uses_decision_engine_fields(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source_dir = root / "Funky House"
            source_dir.mkdir()
            source = source_dir / "Artist - Title.mp3"
            source.write_bytes(b"fake")
            tracks = [{
                "file_path": str(source),
                "filename": source.name,
                "parent_folder": str(source_dir),
                "artist": "Artist",
                "title": "Title",
                "mix_version": "",
                "genre": "",
            }]

            result = classify_genres_from_library(tracks, str(root))
            report_text = Path(result["report_path"]).read_text(encoding="utf-8")

            self.assertIn("local_primary_genre,local_confidence,needs_online_lookup", report_text)
            self.assertIn("online_primary_genre,online_confidence,final_primary_genre", report_text)
            self.assertIn("final_secondary_genre,final_confidence,review_status,classification_reason", report_text)

    def test_metadata_genre_is_written_to_library_and_genre_reports(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "Tagged Artist - Tagged Title.mp3"
            write_fake_id3_mp3(source, {"TCON": "Techno", "TPE1": "Tagged Artist", "TIT2": "Tagged Title"})

            library = scan_music_folder(str(root), show_progress=False)
            track = library["tracks"][0]
            result = classify_genres_from_library(library["tracks"], str(root), prompt_fn=lambda prompt: "n")

            library_json = json.loads(Path(library["json_path"]).read_text(encoding="utf-8"))
            genre_rows = read_csv_rows(Path(result["report_path"]))
            metadata_rows = read_csv_rows(Path(result["metadata_debug_path"]))

            self.assertEqual(track["genre"], "Techno")
            self.assertEqual(library_json[0]["genre"], "Techno")
            self.assertEqual(genre_rows[0]["metadata_genre"], "Techno")
            self.assertEqual(metadata_rows[0]["metadata_genre"], "Techno")
            self.assertEqual(genre_rows[0]["final_primary_genre"], "Techno")
            self.assertNotEqual(genre_rows[0]["review_status"], "UNKNOWN_NEED_REVIEW")
            self.assertIn("07_Techno", genre_rows[0]["copied_path"])

    def test_metadata_debug_report_is_generated_for_genre_classification(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "Artist - Title.mp3"
            write_fake_id3_mp3(source, {"TCON": "Disco House"})
            library = scan_music_folder(str(root), show_progress=False)

            result = classify_genres_from_library(library["tracks"], str(root), prompt_fn=lambda prompt: "n")

            self.assertTrue(Path(result["metadata_debug_path"]).exists())
            text = Path(result["metadata_debug_path"]).read_text(encoding="utf-8")
            self.assertIn("metadata_genre", text)
            self.assertIn("Disco House", text)

    def test_genre_job_analyzes_before_copying(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source_dir = root / "Funky House"
            source_dir.mkdir()
            source = source_dir / "Artist - Title.mp3"
            source.write_bytes(b"fake")
            genre_root = root / "Music Intelligence" / "音乐集合 Collections" / "曲风分类 By Genre"
            prepare_genre_dirs(genre_root)
            track = {
                "file_path": str(source),
                "filename": source.name,
                "parent_folder": str(source_dir),
                "artist": "",
                "title": "",
                "mix_version": "",
                "genre": "",
            }

            result = collect_local_evidence(track)
            make_local_decision(result)
            make_final_decision(result)

            self.assertEqual(list((genre_root / "01_Funky House").iterdir()), [])

            rows = copy_files_by_final_decision([result], str(root), genre_root)

            self.assertEqual(len(rows), 1)
            self.assertTrue(Path(rows[0]["copied_path"]).exists())

    def test_online_allowed_does_not_fabricate_genre_when_lookup_unimplemented(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "Unknown Artist - Unknown Track.mp3"
            source.write_bytes(b"fake")
            tracks = [{
                "file_path": str(source),
                "filename": source.name,
                "parent_folder": str(root / "Inbox"),
                "artist": "",
                "title": "",
                "mix_version": "",
                "genre": "",
            }]

            buffer = io.StringIO()
            with redirect_stdout(buffer):
                result = classify_genres_from_library(tracks, str(root), prompt_fn=lambda prompt: "y")
            row = result["rows"][0]

            self.assertIn("在线曲风查询：未实现，本次未联网查询。", buffer.getvalue())
            self.assertEqual(row["online_lookup_status"], "ONLINE_NOT_IMPLEMENTED")
            self.assertEqual(row["review_status"], "UNKNOWN_NEED_REVIEW")
            self.assertEqual(row["target_folder"], "10_Unknown Need Review")


def write_fake_id3_mp3(path: Path, frames: dict) -> None:
    data = b""
    for frame_id, text in frames.items():
        payload = b"\x03" + text.encode("utf-8")
        data += frame_id.encode("latin1") + synchsafe(len(payload)) + b"\x00\x00" + payload
    path.write_bytes(b"ID3" + bytes([4, 0, 0]) + synchsafe(len(data)) + data + b"\xff\xfb\x90\x64")


def synchsafe(value: int) -> bytes:
    return bytes([
        (value >> 21) & 0x7F,
        (value >> 14) & 0x7F,
        (value >> 7) & 0x7F,
        value & 0x7F,
    ])


def read_csv_rows(path: Path) -> list:
    with path.open("r", encoding="utf-8", newline="") as file:
        return list(csv.DictReader(file))


def contract_block(name: str) -> str:
    contract_path = REPO_DIR / "docs" / "UI_COPY_CONTRACT.md"
    text = contract_path.read_text(encoding="utf-8")
    marker = f"## {name}\n\n```text\n"
    start = text.index(marker) + len(marker)
    end = text.index("\n```", start)
    return text[start:end]


if __name__ == "__main__":
    unittest.main()
