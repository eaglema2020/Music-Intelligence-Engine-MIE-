"""Status output helpers for the terminal Skill."""


def print_status(message: str = "", *, end: str = "\n") -> None:
    """Print a status message immediately.

    The Skill is often run from Codex Desktop or other PTY wrappers, so every
    status line must be flushed right away to avoid the UI looking stuck.
    """
    print(message, end=end, flush=True)


def input_status(prompt: str) -> str:
    """Prompt for input after flushing the prompt text."""
    print_status(prompt, end="")
    return input()
