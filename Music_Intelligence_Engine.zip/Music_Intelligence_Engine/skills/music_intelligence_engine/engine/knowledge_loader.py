"""Load local music knowledge base files."""

import json
import re
from pathlib import Path


KNOWLEDGE_FILES = {
    "artists": "artists.json",
    "labels": "labels.json",
    "remixers": "remixers.json",
    "genre_keywords": "genre_keywords.json",
}


def load_knowledge_base() -> dict:
    knowledge_dir = Path(__file__).resolve().parents[1] / "knowledge"
    notes = []
    result = {}
    for key, filename in KNOWLEDGE_FILES.items():
        path = knowledge_dir / filename
        data = load_json_file(path, notes)
        if key == "genre_keywords":
            result[key] = normalize_keywords(data)
        else:
            result[key] = normalize_mapping(data)
    result["notes"] = notes
    return result


def load_json_file(path: Path, notes: list) -> dict:
    if not path.exists():
        notes.append(f"Knowledge file missing: {path.name}")
        return {}
    try:
        with path.open("r", encoding="utf-8") as file:
            data = json.load(file)
        if not isinstance(data, dict):
            notes.append(f"Knowledge file is not an object: {path.name}")
            return {}
        return data
    except Exception as error:
        notes.append(f"Failed to read {path.name}: {error}")
        return {}


def normalize_mapping(data: dict) -> dict:
    normalized = {}
    for name, value in data.items():
        normalized[normalize_key(name)] = value
    return normalized


def normalize_keywords(data: dict) -> dict:
    normalized = {}
    for genre, keywords in data.items():
        normalized[genre] = [normalize_key(keyword) for keyword in keywords if keyword]
    return normalized


def normalize_key(value: str) -> str:
    text = (value or "").lower().strip()
    text = text.replace("_", " ").replace("-", " ")
    text = re.sub(r"\s+", " ", text)
    return text
