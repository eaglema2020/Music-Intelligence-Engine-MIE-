"""Highest-priority filesystem safety guard."""

import shutil
from datetime import datetime
from pathlib import Path


MUSIC_INTELLIGENCE_DIR = "Music Intelligence"
LIBRARY_DIR = "音乐库 Library"
COLLECTIONS_DIR = "音乐集合 Collections"
RENAMED_COLLECTION_DIR = "文件名整理 Renamed"
GENRE_COLLECTION_DIR = "曲风分类 By Genre"
REPORTS_DIR = "报告 Reports"
LOGS_DIR = "日志 Logs"


def music_intelligence_root(music_root) -> Path:
    return Path(music_root).expanduser().resolve() / MUSIC_INTELLIGENCE_DIR


def music_library_dir(music_root) -> Path:
    return music_intelligence_root(music_root) / LIBRARY_DIR


def logs_dir(music_root) -> Path:
    return music_intelligence_root(music_root) / LOGS_DIR


def assert_safe_output_path(path, music_root) -> Path:
    """Ensure writes stay under <music_root>/Music Intelligence/."""
    target = Path(path).expanduser()
    safe_root = music_intelligence_root(music_root)
    resolved_target = target.resolve()
    resolved_safe_root = safe_root.resolve()
    try:
        resolved_target.relative_to(resolved_safe_root)
    except ValueError:
        raise ValueError(f"Unsafe output path outside Music Intelligence/: {resolved_target}")
    return resolved_target


def assert_source_readonly(path) -> Path:
    """Ensure source exists and is treated as read-only."""
    source = Path(path).expanduser().resolve()
    if not source.exists():
        raise FileNotFoundError(f"Source file does not exist: {source}")
    if not source.is_file():
        raise ValueError(f"Source path is not a file: {source}")
    return source


def safe_copy_file(source, destination, music_root, conflict_strategy: str = "number") -> dict:
    """Copy source into Music Intelligence/ with an explicit conflict strategy.

    conflict_strategy:
    - number: append _02, _03, ...
    - cancel: skip if destination exists
    """
    if conflict_strategy not in {"number", "cancel"}:
        raise ValueError(f"Unsafe or unknown conflict strategy: {conflict_strategy}")

    try:
        source_path = assert_source_readonly(source)
        destination_path = assert_safe_output_path(destination, music_root)
    except FileNotFoundError as error:
        return {"status": "SKIPPED_MISSING_SOURCE", "copied_path": "", "notes": str(error)}

    destination_path.parent.mkdir(parents=True, exist_ok=True)
    final_destination = resolve_destination_conflict(destination_path, conflict_strategy)
    if final_destination is None:
        return {
            "status": "CANCELLED_EXISTS",
            "copied_path": "",
            "notes": f"Destination already exists and user cancelled: {destination_path}",
        }
    shutil.copy2(str(source_path), str(final_destination))
    return {
        "status": "COPIED",
        "copied_path": str(final_destination),
        "notes": f"Copied safely into Music Intelligence/ using conflict strategy: {conflict_strategy}.",
    }


def resolve_destination_conflict(destination: Path, conflict_strategy: str):
    if not destination.exists():
        return destination
    if conflict_strategy == "number":
        return unique_destination(destination)
    if conflict_strategy == "cancel":
        return None
    raise ValueError(f"Unknown conflict strategy: {conflict_strategy}")


def unique_destination(destination: Path) -> Path:
    candidate = destination
    counter = 2
    while candidate.exists():
        candidate = destination.with_name(f"{destination.stem}_{counter:02d}{destination.suffix}")
        counter += 1
    return candidate


def current_run_timestamp() -> str:
    return datetime.now().strftime("%Y-%m-%d_%H%M")


def unique_timestamped_path(base_path: Path, timestamp: str) -> Path:
    candidate = base_path.with_name(f"{base_path.name}_{timestamp}")
    counter = 2
    while candidate.exists():
        candidate = base_path.with_name(f"{base_path.name}_{timestamp}_{counter:02d}")
        counter += 1
    return candidate


def unique_timestamped_report(base_report_path: Path, timestamp: str) -> Path:
    candidate = base_report_path.with_name(f"{base_report_path.stem}_{timestamp}{base_report_path.suffix}")
    counter = 2
    while candidate.exists():
        candidate = base_report_path.with_name(
            f"{base_report_path.stem}_{timestamp}_{counter:02d}{base_report_path.suffix}"
        )
        counter += 1
    return candidate


def output_run_paths(music_root, result_folder_name: str, report_filename: str, extra_report_filenames=None) -> dict:
    extra_report_filenames = extra_report_filenames or []
    root = music_intelligence_root(music_root)
    base_output_dir = assert_safe_output_path(root / COLLECTIONS_DIR / result_folder_name, music_root)
    base_report_path = assert_safe_output_path(root / REPORTS_DIR / report_filename, music_root)
    base_extra_reports = [
        assert_safe_output_path(root / REPORTS_DIR / filename, music_root)
        for filename in extra_report_filenames
    ]
    use_timestamp = (
        base_output_dir.exists()
        or base_report_path.exists()
        or any(path.exists() for path in base_extra_reports)
    )
    timestamp = current_run_timestamp() if use_timestamp else ""

    if timestamp:
        output_dir = assert_safe_output_path(unique_timestamped_path(base_output_dir, timestamp), music_root)
        report_path = assert_safe_output_path(unique_timestamped_report(base_report_path, timestamp), music_root)
        extra_reports = {
            path.name: assert_safe_output_path(unique_timestamped_report(path, timestamp), music_root)
            for path in base_extra_reports
        }
    else:
        output_dir = base_output_dir
        report_path = base_report_path
        extra_reports = {path.name: path for path in base_extra_reports}

    return {
        "output_dir": output_dir,
        "report_path": report_path,
        "extra_reports": extra_reports,
        "timestamp": timestamp,
    }
