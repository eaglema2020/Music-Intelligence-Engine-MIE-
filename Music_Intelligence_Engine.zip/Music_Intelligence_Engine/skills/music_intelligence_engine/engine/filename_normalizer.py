"""Professional DJ filename normalization for copied files."""

import csv
import re
from pathlib import Path

from engine.safety_guard import RENAMED_COLLECTION_DIR, output_run_paths, safe_copy_file


MIX_KEYWORDS = (
    "Extended Mix", "Club Mix", "Original Mix", "Radio Edit", "Dub Mix", "Dub",
    "Instrumental", "Rework", "Re-Edit", "Edit", "Remix", "VIP Mix", "VIP Edit",
    "Bootleg", "Mashup", "Acapella", "Vocal Mix", "Main Mix",
)


def normalize_filename(original_filename: str) -> dict:
    path = Path(original_filename)
    ext = path.suffix
    stem = clean_noise(path.stem)
    artist = ""
    title = ""
    mix_version = ""
    status = "NEEDS_REVIEW"
    confidence = 55
    notes = "Could not reliably identify Artist - Title; cleaned obvious noise only."

    if " - " in stem:
        left, right = stem.split(" - ", 1)
        title_part, mix = extract_mix_version(right)
        if left.strip() and title_part.strip():
            artist = clean_part(left)
            title = clean_part(title_part)
            mix_version = mix
            status = "NORMALIZED"
            confidence = 90 if mix else 80
            notes = "Normalized from filename metadata."

    if status == "NORMALIZED":
        if mix_version:
            cleaned_filename = f"{artist} - {title} ({mix_version}){ext}"
        else:
            cleaned_filename = f"{artist} - {title}{ext}"
    else:
        cleaned_filename = f"{stem}{ext}"

    return {
        "original_filename": original_filename,
        "cleaned_filename": cleaned_filename,
        "artist": artist,
        "title": title,
        "mix_version": mix_version,
        "confidence": confidence,
        "status": status,
        "notes": notes,
    }


def normalize_files_from_library(tracks: list, music_root: str, conflict_strategy: str = "number") -> dict:
    paths = output_run_paths(music_root, RENAMED_COLLECTION_DIR, "filename_normalization_report.csv")
    normalized_dir = paths["output_dir"]
    report_path = paths["report_path"]
    normalized_dir.mkdir(parents=True, exist_ok=True)
    report_path.parent.mkdir(parents=True, exist_ok=True)

    rows = []
    for track in tracks:
        source = Path(track["file_path"])
        normalized = normalize_filename(source.name)
        copy_result = safe_copy_file(
            source,
            normalized_dir / normalized["cleaned_filename"],
            music_root,
            conflict_strategy=conflict_strategy,
        )
        copied_path = copy_result["copied_path"]
        cleaned_filename = Path(copied_path).name if copied_path else normalized["cleaned_filename"]
        rows.append({
            "original_path": str(source),
            "copied_path": copied_path,
            "original_filename": normalized["original_filename"],
            "cleaned_filename": cleaned_filename,
            "artist": normalized["artist"],
            "title": normalized["title"],
            "mix_version": normalized["mix_version"],
            "confidence": normalized["confidence"],
            "status": normalized["status"] if copy_result["status"] == "COPIED" else copy_result["status"],
            "notes": normalized["notes"] if copy_result["status"] == "COPIED" else copy_result["notes"],
        })

    write_normalization_report(report_path, rows)
    return {"output_dir": str(normalized_dir), "report_path": str(report_path), "rows": rows}


def clean_noise(value: str) -> str:
    cleaned = value
    patterns = [
        r"\[[^\]]*(?:www\.|\.com|_com|muzhousebeat)[^\]]*\]",
        r"\([^)]*(?:www\.|\.com|_com|muzhousebeat)[^)]*\)",
        r"\bwww\.[^\s]+", r"\bmuzhousebeat[._]com\b", r"\belectrobuzz\b",
        r"\bzippyshare\b", r"\bdjcity\b", r"\bclubkillers\b", r"\bfreshrecords\b",
        r"\bfree\s+download\b", r"\bdownload\b", r"\b320\s*kbps\b", r"\bHQ\b",
        r"\bWEBRip\b", r"\bWEB\b", r"\bPromo\b", r"\bLossless\b", r"\bMaster\b",
        r"\bFinal2\b", r"\bFinal\b", r"\bClean\b", r"\bDirty\b",
        r"\b(?:19[9][0-9]|20[0-2][0-9])\b",
    ]
    for pattern in patterns:
        cleaned = re.sub(pattern, " ", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"^\s*\d{1,3}\s*[-._ ]+", " ", cleaned)
    cleaned = re.sub(r"\b(?:ft\.?|feat\.?|featuring)\b", "feat.", cleaned, flags=re.IGNORECASE)
    return clean_part(cleaned)


def clean_part(value: str) -> str:
    cleaned = value.replace("__", " ").replace("--", " ")
    cleaned = re.sub(r"\s+", " ", cleaned)
    return cleaned.strip(" -_.")


def extract_mix_version(value: str) -> tuple:
    matches = list(re.finditer(r"\(([^()]*)\)", value))
    for match in reversed(matches):
        content = clean_part(match.group(1))
        if any(keyword.lower() in content.lower() for keyword in MIX_KEYWORDS):
            title = value[: match.start()] + value[match.end():]
            return clean_part(title), content
    return clean_part(re.sub(r"\([^()]*\)", " ", value)), ""


def write_normalization_report(path: Path, rows: list) -> None:
    with path.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=[
            "original_path", "copied_path", "original_filename", "cleaned_filename",
            "artist", "title", "mix_version", "confidence", "status", "notes",
        ])
        writer.writeheader()
        writer.writerows(rows)
