"""Commercial-grade terminal copy for Music Intelligence Engine.

All user-facing menu copy lives here so the product has one standard UI across
machines and releases.
"""


PRODUCT_NAME = "Music Intelligence Engine"
DIVIDER = "──────────────────────────────────────"


START_MENU = f"""{PRODUCT_NAME}
{DIVIDER}

请输入 / Please enter:
1、选择文件夹并扫描 / Select Folder and Scan
0、退出程序 / Exit"""


PATH_PROMPT = """请拖入或粘贴要扫描的音乐文件夹路径，然后按回车：
Drag or paste the music folder path, then press Enter:

提示 / Tips:

* macOS / Windows 都可以直接把文件夹拖到这里
  You can drag a folder here on macOS / Windows
* 也可以复制文件夹路径后粘贴
  You can also copy and paste the folder path
* 路径两边有引号也没关系
  Quotes around the path are OK"""


def scan_result(track_count: int) -> str:
    return (
        "✓ 扫描完成 / Scan Complete\n"
        "\n"
        f"共发现 / Tracks Found：{track_count:,} 首音乐\n"
        "\n"
        "✓ Music Library 已生成\n"
        "\n"
        "生成位置 / Output Location："
    )


def tools_menu(track_count: int) -> str:
    return f"""{PRODUCT_NAME}
{DIVIDER}

✓ 扫描完成 / Scan Complete

共发现 / Tracks Found：{track_count:,} 首音乐

请输入 / Please enter:

1、标准化文件名 / Normalize Filenames
   将音乐文件复制到新的目录，并统一命名格式：
   Copy music files to a new folder and normalize filename format:
   Artist - Title (Mix Version).ext
   不修改原始文件 / Original files are never modified

2、音乐风格分类 / Classify by Genre
   按音乐风格复制到分类文件夹：
   Copy files into genre folders:
   Funky House, Disco House, Nu Disco, Soulful House, House,
   Tech House, Techno, Melodic House Techno, Progressive House
   先读取音频标签与本地知识库，低置信度才进入 Unknown Need Review
   Uses audio tags and local knowledge base; low confidence goes to Unknown Need Review
   不修改原始文件 / Original files are never modified

0、退出程序 / Exit"""


INVALID_OPTION = "无效选项，请重新输入。/ Invalid option, please try again."
INVALID_PATH = "路径无效，请重新拖入或粘贴文件夹路径。/ Invalid path, please drag or paste again."
SELECTED_FOLDER = "\n已选择文件夹 / Selected Folder："
SCANNING_FILES = "\n开始扫描音乐文件… / Scanning music files…\n"
DONE = "\n✓ 处理完成 / Done\n"
OUTPUT_LOCATION = "输出位置 / Output Location："
REPORT_LOCATION = "\n报告位置 / Report Location："


def selected_tool_1() -> str:
    return "\n已选择 / Selected：标准化文件名 / Normalize Filenames\n"


def selected_tool_2() -> str:
    return "\n已选择 / Selected：音乐风格分类 / Classify by Genre\n"


PROCESSING = "开始处理… / Processing…\n"
