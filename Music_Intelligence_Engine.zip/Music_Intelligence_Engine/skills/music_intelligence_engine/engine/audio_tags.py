"""Lightweight audio metadata reader using only the Python standard library."""

from pathlib import Path


TEXT_FRAMES = {
    "TCON": "genre",
    "TPE1": "artist",
    "TIT2": "title",
    "TPUB": "label",
    "TALB": "album",
    "TPE4": "remixer",
}


def read_audio_tags(path) -> dict:
    audio_path = Path(path)
    if audio_path.suffix.lower() == ".mp3":
        return read_id3v2_tags(audio_path)
    return empty_tags()


def empty_tags() -> dict:
    return {
        "artist": "",
        "title": "",
        "genre": "",
        "label": "",
        "album": "",
        "remixer": "",
        "tag_read_status": "NO_SUPPORTED_TAG_READER",
        "tag_read_notes": "",
    }


def read_id3v2_tags(path: Path) -> dict:
    tags = empty_tags()
    tags["tag_read_status"] = "NO_ID3_TAG"
    try:
        with path.open("rb") as file:
            header = file.read(10)
            if len(header) < 10 or header[:3] != b"ID3":
                return tags
            version_major = header[3]
            tag_size = synchsafe_to_int(header[6:10])
            data = file.read(tag_size)
    except Exception as error:
        tags["tag_read_status"] = "ERROR"
        tags["tag_read_notes"] = str(error)
        return tags

    frames = parse_id3_frames(data, version_major)
    for frame_id, field in TEXT_FRAMES.items():
        if frame_id in frames:
            tags[field] = decode_text_frame(frames[frame_id]).strip("\x00").strip()
    tags["tag_read_status"] = "READ" if any(tags[field] for field in TEXT_FRAMES.values()) else "NO_TEXT_TAGS"
    return tags


def parse_id3_frames(data: bytes, version_major: int) -> dict:
    frames = {}
    offset = 0
    while offset + 10 <= len(data):
        frame_id_bytes = data[offset:offset + 4]
        if frame_id_bytes == b"\x00\x00\x00\x00":
            break
        try:
            frame_id = frame_id_bytes.decode("latin1")
        except UnicodeDecodeError:
            break
        if not frame_id.strip("\x00"):
            break
        size_bytes = data[offset + 4:offset + 8]
        frame_size = synchsafe_to_int(size_bytes) if version_major == 4 else int.from_bytes(size_bytes, "big")
        if frame_size <= 0:
            break
        frame_data_start = offset + 10
        frame_data_end = frame_data_start + frame_size
        if frame_data_end > len(data):
            break
        frames[frame_id] = data[frame_data_start:frame_data_end]
        offset = frame_data_end
    return frames


def decode_text_frame(data: bytes) -> str:
    if not data:
        return ""
    encoding = data[0]
    payload = data[1:]
    if encoding == 0:
        return payload.decode("latin1", errors="replace")
    if encoding == 1:
        return payload.decode("utf-16", errors="replace")
    if encoding == 2:
        return payload.decode("utf-16-be", errors="replace")
    if encoding == 3:
        return payload.decode("utf-8", errors="replace")
    return payload.decode("utf-8", errors="replace")


def synchsafe_to_int(value: bytes) -> int:
    total = 0
    for byte in value:
        total = (total << 7) | (byte & 0x7F)
    return total
