"""Path cleanup helpers for pasted or dragged folder paths."""


def clean_dragged_path(raw_path: str) -> str:
    """Normalize a folder path pasted or dragged into the terminal."""
    value = raw_path.strip()
    value = value.strip("'").strip('"').strip()
    value = value.replace("\\ ", " ")
    value = value.replace("\\(", "(")
    value = value.replace("\\)", ")")
    value = value.replace("\\[", "[")
    value = value.replace("\\]", "]")
    value = value.replace("\\&", "&")
    value = value.replace("\\'", "'")
    value = value.replace('\\"', '"')
    value = value.replace("\\\\", "\\")
    return value.strip()
