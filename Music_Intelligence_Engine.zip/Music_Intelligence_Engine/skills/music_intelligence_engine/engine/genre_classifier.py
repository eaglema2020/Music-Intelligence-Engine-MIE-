"""Safe genre classification job flow.

The job always analyzes all tracks first, creates final decisions, and only
then copies files into genre folders.
"""

import csv
from pathlib import Path

from engine.filename_normalizer import normalize_filename
from engine.genre_decision_engine import GENRE_FOLDERS as DECISION_FOLDERS
from engine.genre_decision_engine import UNKNOWN_FOLDER, decide_genre
from engine.safety_guard import GENRE_COLLECTION_DIR, output_run_paths, safe_copy_file
from engine.status import input_status, print_status


GENRE_FOLDERS = [
    "01_Funky House",
    "02_Disco House",
    "03_Nu Disco",
    "04_Soulful House",
    "05_House",
    "06_Tech House",
    "07_Techno",
    "08_Melodic House Techno",
    "09_Progressive House",
    "10_Unknown Need Review",
]


def classify_genres_from_library(
    tracks: list,
    music_root: str,
    prompt_fn=None,
    conflict_strategy: str = "number",
    allow_online_lookup: bool = False,
) -> dict:
    paths = output_run_paths(
        music_root,
        GENRE_COLLECTION_DIR,
        "genre_classification_report.csv",
        extra_report_filenames=["metadata_debug_report.csv"],
    )
    genre_root = paths["output_dir"]
    report_path = paths["report_path"]
    metadata_debug_path = paths["extra_reports"]["metadata_debug_report.csv"]
    prepare_genre_dirs(genre_root)
    report_path.parent.mkdir(parents=True, exist_ok=True)

    print_status("正在分析本地曲风信息...")
    results = [collect_local_evidence(track) for track in tracks]
    for result in results:
        make_local_decision(result)
    print_status("本地分析完成\n")

    needs_lookup = [result for result in results if result["needs_online_lookup"]]
    print_status(f"需要联网查询：{len(needs_lookup)} 首")
    online_allowed = allow_online_lookup
    if needs_lookup and not allow_online_lookup:
        online_allowed = ask_online_permission(prompt_fn)

    if online_allowed and needs_lookup:
        print_status("\n在线曲风查询：未实现，本次未联网查询。")
        for result in needs_lookup:
            lookup_online_evidence(result)
        print_status()
    else:
        for result in needs_lookup:
            result["online_evidence"] = empty_online_evidence(
                "ONLINE_DECLINED" if needs_lookup else "NOT_REQUESTED",
                "Online lookup declined by user.",
            )

    print_status("正在生成最终分类结果...\n")
    for result in results:
        make_final_decision(result)

    write_metadata_debug_report(metadata_debug_path, results)
    print_status("正在复制文件到曲风文件夹...\n")
    rows = copy_files_by_final_decision(results, music_root, genre_root, conflict_strategy)
    write_genre_report(report_path, rows)
    summary = summarize_rows(rows)
    print_status("✓ 音乐风格分类完成\n")
    print_status(f"总数：{summary['total']}")
    print_status(f"CONFIDENT：{summary['CONFIDENT']}")
    print_status(f"REVIEW_RECOMMENDED：{summary['REVIEW_RECOMMENDED']}")
    print_status(f"Unknown Need Review：{summary['UNKNOWN_NEED_REVIEW']}\n")
    return {
        "output_dir": str(genre_root),
        "report_path": str(report_path),
        "metadata_debug_path": str(metadata_debug_path),
        "rows": rows,
        "summary": summary,
    }


def collect_local_evidence(track: dict) -> dict:
    return {
        "track": track,
        "local_evidence": {
            "genre": track.get("genre", ""),
            "parent_folder": track.get("parent_folder", ""),
            "filename": track.get("filename", ""),
            "artist": track.get("artist", ""),
            "title": track.get("title", ""),
            "mix_version": track.get("mix_version", ""),
            "label": track.get("label", ""),
            "remixer": track.get("remixer", ""),
        },
        "local_decision": {},
        "online_evidence": empty_online_evidence("NOT_REQUESTED", ""),
        "final_decision": {},
        "needs_online_lookup": False,
    }


def make_local_decision(result: dict) -> dict:
    decision = decide_genre(result["track"], allow_online_lookup=False)
    result["local_decision"] = decision
    result["needs_online_lookup"] = decision["confidence"] < 80
    return decision


def lookup_online_evidence(result: dict) -> dict:
    # Real online lookup is intentionally not implemented yet.
    result["online_evidence"] = empty_online_evidence(
        "ONLINE_NOT_IMPLEMENTED",
        "Online lookup interface exists, but real lookup is not implemented.",
    )
    return result["online_evidence"]


def make_final_decision(result: dict) -> dict:
    local = result["local_decision"]
    online = result["online_evidence"]
    online_confidence = online.get("confidence", 0)
    if online_confidence > local["confidence"]:
        primary = online["primary_genre"]
        secondary = online.get("secondary_genre", "")
        confidence = online_confidence
        reason = f"{local['classification_reason']}; Online evidence selected final genre."
    else:
        primary = local["primary_genre"]
        secondary = local["secondary_genre"]
        confidence = local["confidence"]
        reason = local["classification_reason"]
        if online.get("online_lookup_status") in {"ONLINE_DECLINED", "ONLINE_NOT_IMPLEMENTED"}:
            reason = f"{reason}; {online.get('notes', '')}".strip("; ")

    if confidence >= 80:
        review_status = "CONFIDENT"
        target_folder = DECISION_FOLDERS.get(primary, UNKNOWN_FOLDER)
    elif confidence >= 55 and primary != "Unknown":
        review_status = "REVIEW_RECOMMENDED"
        target_folder = DECISION_FOLDERS.get(primary, UNKNOWN_FOLDER)
    else:
        primary = "Unknown"
        secondary = ""
        review_status = "UNKNOWN_NEED_REVIEW"
        target_folder = UNKNOWN_FOLDER

    final = {
        "final_primary_genre": primary,
        "final_secondary_genre": secondary,
        "final_confidence": confidence,
        "review_status": review_status,
        "target_folder": target_folder,
        "classification_reason": reason,
    }
    result["final_decision"] = final
    return final


def copy_files_by_final_decision(results: list, music_root: str, genre_root: Path, conflict_strategy: str = "number") -> list:
    rows = []
    for result in results:
        track = result["track"]
        final = result["final_decision"]
        destination = genre_root / final["target_folder"] / normalized_output_filename(track)
        copy_result = safe_copy_file(track["file_path"], destination, music_root, conflict_strategy=conflict_strategy)
        copied = copy_result["status"] == "COPIED"
        rows.append(build_report_row(result, copy_result, copied))
    return rows


def build_report_row(result: dict, copy_result: dict, copied: bool) -> dict:
    track = result["track"]
    local = result["local_decision"]
    online = result["online_evidence"]
    final = result["final_decision"]
    status = final["review_status"] if copied else copy_result["status"]
    notes = "Copied safely after final genre decision." if copied else copy_result["notes"]
    return {
        "original_path": track["file_path"],
        "copied_path": copy_result["copied_path"],
        "artist": track.get("artist", ""),
        "title": track.get("title", ""),
        "mix_version": track.get("mix_version", ""),
        "metadata_genre": track.get("genre", ""),
        "local_primary_genre": local["primary_genre"],
        "local_confidence": local["confidence"],
        "needs_online_lookup": str(bool(result["needs_online_lookup"])),
        "online_lookup_status": online["online_lookup_status"],
        "online_primary_genre": online.get("primary_genre", ""),
        "online_confidence": online.get("confidence", 0),
        "final_primary_genre": final["final_primary_genre"],
        "final_secondary_genre": final["final_secondary_genre"],
        "final_confidence": final["final_confidence"],
        "review_status": final["review_status"],
        "classification_reason": final["classification_reason"],
        "target_folder": final["target_folder"],
        "status": status,
        "notes": notes,
    }


def empty_online_evidence(status: str, notes: str) -> dict:
    return {
        "online_lookup_status": status,
        "primary_genre": "",
        "secondary_genre": "",
        "confidence": 0,
        "notes": notes,
    }


def ask_online_permission(prompt_fn) -> bool:
    prompt = (
        "是否允许联网查询公开音乐信息？\n"
        "请输入 y/n："
    )
    try:
        if prompt_fn is None:
            return input_status(prompt).strip().lower() == "y"
        return prompt_fn(prompt).strip().lower() == "y"
    except EOFError:
        return False


def prepare_genre_dirs(genre_root: Path) -> None:
    genre_root.mkdir(parents=True, exist_ok=True)
    for folder in GENRE_FOLDERS:
        (genre_root / folder).mkdir(parents=True, exist_ok=True)


def write_genre_report(path: Path, rows: list) -> None:
    with path.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=[
            "original_path",
            "copied_path",
            "artist",
            "title",
            "mix_version",
            "metadata_genre",
            "local_primary_genre",
            "local_confidence",
            "needs_online_lookup",
            "online_lookup_status",
            "online_primary_genre",
            "online_confidence",
            "final_primary_genre",
            "final_secondary_genre",
            "final_confidence",
            "review_status",
            "classification_reason",
            "target_folder",
            "status",
            "notes",
        ])
        writer.writeheader()
        writer.writerows(rows)


def write_metadata_debug_report(path: Path, results: list) -> None:
    with path.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=[
            "original_path",
            "filename",
            "metadata_artist",
            "metadata_title",
            "metadata_genre",
            "metadata_label",
            "metadata_album",
            "metadata_remixer",
            "tag_read_status",
            "tag_read_notes",
            "local_primary_genre",
            "local_confidence",
            "needs_online_lookup",
            "final_primary_genre",
            "final_confidence",
            "review_status",
        ])
        writer.writeheader()
        for result in results:
            track = result["track"]
            local = result["local_decision"]
            final = result["final_decision"]
            writer.writerow({
                "original_path": track.get("file_path", ""),
                "filename": track.get("filename", ""),
                "metadata_artist": track.get("artist", ""),
                "metadata_title": track.get("title", ""),
                "metadata_genre": track.get("genre", ""),
                "metadata_label": track.get("label", ""),
                "metadata_album": track.get("album", ""),
                "metadata_remixer": track.get("remixer", ""),
                "tag_read_status": track.get("tag_read_status", ""),
                "tag_read_notes": track.get("tag_read_notes", ""),
                "local_primary_genre": local.get("primary_genre", ""),
                "local_confidence": local.get("confidence", 0),
                "needs_online_lookup": str(bool(result.get("needs_online_lookup", False))),
                "final_primary_genre": final.get("final_primary_genre", ""),
                "final_confidence": final.get("final_confidence", 0),
                "review_status": final.get("review_status", ""),
            })


def summarize_rows(rows: list) -> dict:
    summary = {"total": len(rows), "CONFIDENT": 0, "REVIEW_RECOMMENDED": 0, "UNKNOWN_NEED_REVIEW": 0}
    for row in rows:
        if row["review_status"] in summary:
            summary[row["review_status"]] += 1
    return summary


def normalized_output_filename(track: dict) -> str:
    """Use the shared filename normalizer for genre-sorted copies."""
    normalized = normalize_filename(track["filename"])
    return normalized["cleaned_filename"]
