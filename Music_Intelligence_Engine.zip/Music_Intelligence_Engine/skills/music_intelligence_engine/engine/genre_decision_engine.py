"""Genre Decision Engine backed by a local music knowledge base."""

import re

from engine.knowledge_loader import load_knowledge_base, normalize_key


GENRE_ORDER = [
    "Funky House",
    "Disco House",
    "Nu Disco",
    "Soulful House",
    "Tech House",
    "Melodic House Techno",
    "Progressive House",
    "Techno",
    "House",
]

GENRE_FOLDERS = {
    "Funky House": "01_Funky House",
    "Disco House": "02_Disco House",
    "Nu Disco": "03_Nu Disco",
    "Soulful House": "04_Soulful House",
    "House": "05_House",
    "Tech House": "06_Tech House",
    "Techno": "07_Techno",
    "Melodic House Techno": "08_Melodic House Techno",
    "Progressive House": "09_Progressive House",
}

UNKNOWN_FOLDER = "10_Unknown Need Review"


def decide_genre(track: dict, allow_online_lookup: bool = False) -> dict:
    knowledge = load_knowledge_base()
    candidates = {}
    reasons = []
    evidence_sources = []
    genre_tags = []

    add_keyword_evidence(candidates, reasons, evidence_sources, genre_tags, knowledge, "ID3 Genre", track.get("genre", ""), 90)
    add_keyword_evidence(candidates, reasons, evidence_sources, genre_tags, knowledge, "Folder", track.get("parent_folder", ""), 85)
    add_keyword_evidence(candidates, reasons, evidence_sources, genre_tags, knowledge, "Filename", track.get("filename", ""), 80)
    add_artist_evidence(candidates, reasons, evidence_sources, genre_tags, knowledge, track)
    add_label_evidence(candidates, reasons, evidence_sources, genre_tags, knowledge, track)
    add_remixer_evidence(candidates, reasons, evidence_sources, genre_tags, knowledge, track)
    add_keyword_evidence(candidates, reasons, evidence_sources, genre_tags, knowledge, "Title", track.get("title", ""), 70)
    add_keyword_evidence(candidates, reasons, evidence_sources, genre_tags, knowledge, "Mix Version", track.get("mix_version", ""), 70)

    online_status = "ONLINE_NOT_IMPLEMENTED" if allow_online_lookup else "NOT_REQUESTED"
    if not candidates:
        return build_unknown("No reliable local genre evidence found.", online_status)

    ranked = sorted(candidates.items(), key=lambda item: (-item[1]["score"], genre_rank(item[0])))
    primary_genre, primary_data = ranked[0]
    secondary_genre = ranked[1][0] if len(ranked) > 1 and ranked[1][1]["score"] > 0 else ""
    confidence = min(100, int(primary_data["score"]))

    if confidence >= 80:
        review_status = "CONFIDENT"
        target_folder = GENRE_FOLDERS[primary_genre]
    elif confidence >= 50:
        review_status = "REVIEW_RECOMMENDED"
        target_folder = GENRE_FOLDERS[primary_genre]
    else:
        review_status = "UNKNOWN_NEED_REVIEW"
        target_folder = UNKNOWN_FOLDER

    if review_status == "UNKNOWN_NEED_REVIEW":
        primary_genre = "Unknown"
        secondary_genre = ""

    return {
        "primary_genre": primary_genre,
        "secondary_genre": secondary_genre,
        "genre_tags": unique_preserve_order(genre_tags + list(candidates.keys())),
        "confidence": confidence,
        "review_status": review_status,
        "evidence_sources": unique_preserve_order(evidence_sources),
        "classification_reason": "; ".join(reasons) if reasons else "No reliable local genre evidence found.",
        "target_folder": target_folder,
        "online_lookup_status": online_status,
    }


def add_keyword_evidence(candidates, reasons, sources, tags, knowledge, source_name, text, base_score):
    value = normalize_key(text)
    if not value:
        return
    for genre in GENRE_ORDER:
        for keyword in knowledge.get("genre_keywords", {}).get(genre, []):
            if keyword and contains_keyword(value, keyword):
                score = min(base_score, 80) if genre == "House" else base_score
                add_candidate(candidates, genre, score, source_name)
                sources.append(source_name)
                tags.append(genre)
                reasons.append(f"Keyword: {source_name.lower()} contains {keyword} -> {genre}")
                return


def contains_keyword(value: str, keyword: str) -> bool:
    pattern = r"(?<![a-z0-9])" + re.escape(keyword) + r"(?![a-z0-9])"
    return re.search(pattern, value) is not None


def add_artist_evidence(candidates, reasons, sources, tags, knowledge, track):
    artist_texts = [track.get("artist", ""), inferred_artist_from_filename(track.get("filename", ""))]
    for artist in artist_texts:
        match_name, entry = lookup_knowledge_entry(knowledge.get("artists", {}), artist)
        if not entry:
            continue
        score = min(int(entry.get("confidence", 75)), 75)
        primary = entry.get("primary_genre", "")
        add_candidate(candidates, primary, score, "Artist knowledge")
        for secondary in entry.get("secondary_genres", []):
            add_candidate(candidates, secondary, max(45, score - 12), "Artist knowledge")
        sources.append("Artist knowledge")
        tags.extend(entry.get("tags", []))
        reasons.append(f"Artist knowledge: {display_name(match_name)} -> {primary} / {', '.join(entry.get('secondary_genres', []))}")
        return


def add_label_evidence(candidates, reasons, sources, tags, knowledge, track):
    match_name, entry = lookup_knowledge_entry(knowledge.get("labels", {}), track.get("label", ""))
    if not entry:
        return
    score = min(int(entry.get("confidence", 85)), 90)
    primary = entry.get("primary_genre", "")
    add_candidate(candidates, primary, score, "Label knowledge")
    for secondary in entry.get("secondary_genres", []):
        add_candidate(candidates, secondary, max(50, score - 10), "Label knowledge")
    sources.append("Label knowledge")
    tags.extend(entry.get("tags", []))
    reasons.append(f"Label knowledge: {display_name(match_name)} -> {primary}")


def add_remixer_evidence(candidates, reasons, sources, tags, knowledge, track):
    filename = track.get("filename", "")
    filename_remix_text = filename if "remix" in normalize_key(filename) or "rework" in normalize_key(filename) else ""
    text = " ".join([
        track.get("remixer", ""),
        track.get("mix_version", ""),
        filename_remix_text,
    ])
    match_name, entry = lookup_knowledge_entry_in_text(knowledge.get("remixers", {}), text)
    if not entry:
        return
    score = min(int(entry.get("confidence", 70)), 70)
    primary = entry.get("primary_genre", "")
    add_candidate(candidates, primary, score, "Remixer knowledge")
    for secondary in entry.get("secondary_genres", []):
        add_candidate(candidates, secondary, max(45, score - 12), "Remixer knowledge")
    sources.append("Remixer knowledge")
    tags.extend(entry.get("tags", []))
    reasons.append(f"Remixer knowledge: {display_name(match_name)} -> {primary}")


def add_candidate(candidates, genre, score, source):
    if not genre:
        return
    current = candidates.setdefault(genre, {"score": 0, "sources": []})
    if current["score"]:
        current["score"] = min(100, max(current["score"], score) + 8)
    else:
        current["score"] = score
    current["sources"].append(source)


def lookup_knowledge_entry(mapping: dict, value: str) -> tuple:
    key = normalize_key(value)
    if not key:
        return "", None
    return key, mapping.get(key)


def lookup_knowledge_entry_in_text(mapping: dict, value: str) -> tuple:
    text = normalize_key(value)
    if not text:
        return "", None
    for key, entry in mapping.items():
        if key in text:
            return key, entry
    return "", None


def inferred_artist_from_filename(filename: str) -> str:
    stem = (filename or "").rsplit(".", 1)[0]
    if " - " not in stem:
        return ""
    return stem.split(" - ", 1)[0]


def genre_rank(genre: str) -> int:
    try:
        return GENRE_ORDER.index(genre)
    except ValueError:
        return len(GENRE_ORDER)


def build_unknown(reason: str, online_status: str) -> dict:
    return {
        "primary_genre": "Unknown",
        "secondary_genre": "",
        "genre_tags": [],
        "confidence": 0,
        "review_status": "UNKNOWN_NEED_REVIEW",
        "evidence_sources": [],
        "classification_reason": reason,
        "target_folder": UNKNOWN_FOLDER,
        "online_lookup_status": online_status,
    }


def unique_preserve_order(values: list) -> list:
    seen = set()
    result = []
    for value in values:
        if value and value not in seen:
            seen.add(value)
            result.append(value)
    return result


def display_name(normalized_name: str) -> str:
    return " ".join(part.capitalize() for part in normalized_name.split())
