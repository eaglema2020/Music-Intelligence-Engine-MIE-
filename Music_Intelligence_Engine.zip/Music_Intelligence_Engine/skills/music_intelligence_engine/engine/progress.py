"""Terminal progress helpers."""

from engine.status import print_status


def render_progress(current: int, total: int, width: int = 20) -> str:
    if total <= 0:
        percent = 0
        filled = 0
    else:
        percent = int((current / total) * 100)
        filled = int(width * current / total)
    bar = "█" * filled + "░" * (width - filled)
    return f"[{bar}] {percent:>3}%  {current:,} / {total:,}"


def print_progress(current: int, total: int) -> None:
    print_status("\r" + render_progress(current, total), end="")
    if current >= total:
        print_status()
