"""Recursive music library scanner."""

import json
from pathlib import Path

from engine.audio_tags import read_audio_tags
from engine.progress import print_progress
from engine.safety_guard import assert_safe_output_path, logs_dir, music_intelligence_root, music_library_dir
from engine.status import print_status


SUPPORTED_AUDIO_EXTENSIONS = {".mp3", ".wav", ".aiff", ".aif", ".flac", ".m4a"}


def scan_music_folder(folder_path: str, show_progress: bool = True, progress_callback=None) -> dict:
    music_root = Path(folder_path).expanduser().resolve()
    if not music_root.exists() or not music_root.is_dir():
        raise FileNotFoundError(f"Music folder does not exist: {music_root}")

    if show_progress:
        print_status("正在统计音乐文件...")
    music_files = find_music_files(music_root)
    total = len(music_files)

    if show_progress:
        print_status(f"已找到 {total:,} 首支持格式的音乐文件。")
        if total:
            print_status("正在扫描音乐文件夹...\n")

    tracks = []
    for index, path in enumerate(music_files, start=1):
        tracks.append(build_track_record(index, path))
        if progress_callback is not None:
            progress_callback(index, total)
        elif show_progress:
            print_progress(index, total)

    library_dir = assert_safe_output_path(music_library_dir(music_root), music_root)
    library_dir.mkdir(parents=True, exist_ok=True)
    assert_safe_output_path(logs_dir(music_root), music_root).mkdir(parents=True, exist_ok=True)
    json_path = assert_safe_output_path(library_dir / "music_library.json", music_root)
    m3u_path = assert_safe_output_path(library_dir / "music_library.m3u", music_root)
    write_music_library_json(json_path, tracks)
    write_music_library_m3u(m3u_path, tracks)

    return {
        "tracks": tracks,
        "total": total,
        "json_path": str(json_path),
        "m3u_path": str(m3u_path),
        "music_root": str(music_root),
        "status": "SCANNED" if total else "NO_SUPPORTED_FILES",
    }


def find_music_files(music_root: Path) -> list:
    output_root = music_intelligence_root(music_root)
    files = []
    for path in music_root.rglob("*"):
        if output_root in path.parents:
            continue
        if path.is_file() and path.suffix.lower() in SUPPORTED_AUDIO_EXTENSIONS:
            files.append(path.resolve())
    return sorted(files)


def build_track_record(index: int, path: Path) -> dict:
    tags = read_audio_tags(path)
    return {
        "id": f"MIE{index:06d}",
        "file_path": str(path),
        "filename": path.name,
        "extension": path.suffix.lower(),
        "parent_folder": str(path.parent),
        "artist": tags.get("artist", ""),
        "title": tags.get("title", ""),
        "mix_version": "",
        "genre": tags.get("genre", ""),
        "label": tags.get("label", ""),
        "album": tags.get("album", ""),
        "remixer": tags.get("remixer", ""),
        "tag_read_status": tags.get("tag_read_status", ""),
        "tag_read_notes": tags.get("tag_read_notes", ""),
        "status": "SCANNED",
    }


def write_music_library_json(path: Path, tracks: list) -> None:
    with path.open("w", encoding="utf-8") as file:
        json.dump(tracks, file, ensure_ascii=False, indent=2)


def write_music_library_m3u(path: Path, tracks: list) -> None:
    with path.open("w", encoding="utf-8") as file:
        file.write("#EXTM3U\n")
        for track in tracks:
            file.write(f"{track['file_path']}\n")


def load_music_library(music_root: str) -> list:
    path = music_library_dir(music_root) / "music_library.json"
    with path.open("r", encoding="utf-8") as file:
        return json.load(file)
