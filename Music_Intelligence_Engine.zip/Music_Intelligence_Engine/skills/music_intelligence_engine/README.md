# Music Intelligence Engine

Music Intelligence Engine is a local, copy-only DJ music library organizer.

It scans a selected music folder, builds a local Music Library, normalizes copied filenames, and classifies copied files by genre using audio tags plus a local Music Knowledge Base.

## Current Version

```text
Version: v0.1.0-alpha
Status: alpha_release_candidate
```

## Safety Promise

The Skill is designed for local DJ libraries and follows these rules:

1. Original music files are read-only.
2. Original files are never deleted, moved, renamed, modified, or overwritten.
3. All audio output is copy-only.
4. All output is written inside the selected folder under `Music Intelligence/`.
5. Repeated runs never overwrite old result folders or reports.
6. Repeated runs create timestamped output folders and report files.

## Run

```bash
python3 skill.py
```

The Skill uses synchronous terminal input only. It does not open Finder, tkinter dialogs, background tasks, or asynchronous folder pickers.

## Folder Input

When prompted, drag or paste a music folder path into the terminal and press Enter.

```text
请拖入或粘贴要扫描的音乐文件夹路径，然后按回车：
Drag or paste the music folder path, then press Enter:
```

The Skill cleans leading/trailing spaces, quotes, and macOS drag-path escaping.

## Standard Terminal UI

All menu copy is centralized in:

```text
engine/ui_text.py
```

This keeps the released Skill consistent across computers.

The canonical product copy contract lives at:

```text
../../docs/UI_COPY_CONTRACT.md
```

Tests compare the generated terminal UI against that contract exactly.

Do not summarize menu descriptions as placeholder text. When showing the menu in docs, tests, or AI-agent output, use the full locked copy.

### First Menu

```text
Music Intelligence Engine
──────────────────────────────────────

请输入 / Please enter:
1、选择文件夹并扫描 / Select Folder and Scan
0、退出程序 / Exit
```

### Second Menu

```text
Music Intelligence Engine
──────────────────────────────────────

✓ 扫描完成 / Scan Complete

共发现 / Tracks Found：24 首音乐

请输入 / Please enter:

1、标准化文件名 / Normalize Filenames
   将音乐文件复制到新的目录，并统一命名格式：
   Copy music files to a new folder and normalize filename format:
   Artist - Title (Mix Version).ext
   不修改原始文件 / Original files are never modified

2、音乐风格分类 / Classify by Genre
   按音乐风格复制到分类文件夹：
   Copy files into genre folders:
   Funky House, Disco House, Nu Disco, Soulful House, House,
   Tech House, Techno, Melodic House Techno, Progressive House
   先读取音频标签与本地知识库，低置信度才进入 Unknown Need Review
   Uses audio tags and local knowledge base; low confidence goes to Unknown Need Review
   不修改原始文件 / Original files are never modified

0、退出程序 / Exit
```

The full second menu is printed after every completed tool action.

## Output Structure

All output is created inside the selected music folder:

```text
Selected Music Folder/
└── Music Intelligence/
    ├── 音乐库 Library/
    │   ├── music_library.json
    │   └── music_library.m3u
    ├── 音乐集合 Collections/
    │   ├── 文件名整理 Renamed/
    │   └── 曲风分类 By Genre/
    ├── 报告 Reports/
    │   ├── filename_normalization_report.csv
    │   ├── metadata_debug_report.csv
    │   └── genre_classification_report.csv
    └── 日志 Logs/
```

Repeated runs create timestamped outputs:

```text
Music Intelligence/音乐集合 Collections/文件名整理 Renamed_YYYY-MM-DD_HHMM/
Music Intelligence/音乐集合 Collections/曲风分类 By Genre_YYYY-MM-DD_HHMM/
Music Intelligence/报告 Reports/filename_normalization_report_YYYY-MM-DD_HHMM.csv
Music Intelligence/报告 Reports/metadata_debug_report_YYYY-MM-DD_HHMM.csv
Music Intelligence/报告 Reports/genre_classification_report_YYYY-MM-DD_HHMM.csv
```

## Music Library

The scanner creates:

```text
Music Intelligence/音乐库 Library/music_library.json
Music Intelligence/音乐库 Library/music_library.m3u
```

For MP3 files, the scanner reads ID3v2 text frames using the Python standard library:

```text
TCON -> genre
TPE1 -> artist
TIT2 -> title
TPUB -> label
TALB -> album
TPE4 -> remixer
```

If metadata genre is read, it is written into:

```text
music_library.json
metadata_debug_report.csv
genre_classification_report.csv
```

## Filename Normalization

Filename normalization copies files to:

```text
Music Intelligence/音乐集合 Collections/文件名整理 Renamed/
```

Standard filename format:

```text
Artist - Title (Mix Version).ext
```

If the Skill cannot confidently identify Artist / Title / Mix Version, the file is still copied safely and marked for review in the report.

## Genre Classification

Genre classification copies files to:

```text
Music Intelligence/音乐集合 Collections/曲风分类 By Genre/
```

Supported top-level folders:

```text
01_Funky House/
02_Disco House/
03_Nu Disco/
04_Soulful House/
05_House/
06_Tech House/
07_Techno/
08_Melodic House Techno/
09_Progressive House/
10_Unknown Need Review/
```

The Genre Decision Engine uses:

1. ID3 Genre tags
2. Folder path
3. Filename keywords
4. Artist knowledge
5. Label knowledge
6. Remixer knowledge
7. Title and Mix Version keywords

Local knowledge files live in:

```text
knowledge/artists.json
knowledge/labels.json
knowledge/remixers.json
knowledge/genre_keywords.json
```

Genre classification is a job flow:

```text
collect_local_evidence
make_local_decision
lookup_online_evidence
make_final_decision
copy_files_by_final_decision
```

Analysis happens first. Files are copied only after all final decisions are complete.

## Confidence Rules

```text
final_confidence >= 80
  CONFIDENT
  Copy to primary genre folder

55 <= final_confidence < 80
  REVIEW_RECOMMENDED
  Still copy to primary genre folder

final_confidence < 55
  UNKNOWN_NEED_REVIEW
  Copy to 10_Unknown Need Review
```

Unknown Need Review is only a final decision, never an early analysis-stage destination.

## Online Lookup

The online lookup flow is present but real web lookup is not implemented yet.

If online lookup is requested, the current status is:

```text
ONLINE_NOT_IMPLEMENTED
```

The terminal also prints:

```text
在线曲风查询：未实现，本次未联网查询。
```

The Skill does not fabricate online genre results.

## Tests

Run from `Music_Intelligence_Engine/skills/music_intelligence_engine/`:

```bash
python3 -m unittest tests/test_skill.py
```

Run from the repository root:

```bash
python -m pytest skills/music_intelligence_engine/tests
```

On systems where the command is named `python3`, run:

```bash
python3 -m pytest skills/music_intelligence_engine/tests
```

The test suite covers:

1. Safe copy-only file operations
2. Repeated timestamp output
3. Menu copy standards
4. ID3 genre reading
5. Filename normalization
6. Genre Decision Engine
7. Knowledge Base loading
8. Analysis-before-copy genre job flow
