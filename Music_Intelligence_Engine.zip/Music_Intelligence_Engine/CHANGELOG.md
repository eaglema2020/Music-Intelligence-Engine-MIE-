# Changelog

## v0.1.0-alpha

- Added local music folder scanning
- Added Music Library JSON / M3U generation
- Added filename standardization
- Added experimental genre classification
- Added metadata debug report
- Added safe-copy workflow
- Added bilingual output folder structure
